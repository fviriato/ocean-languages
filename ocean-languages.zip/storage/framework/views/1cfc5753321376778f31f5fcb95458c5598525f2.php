<?php $__env->startSection('titulo', 'Escolaridade'); ?>

<?php $__env->startSection('content_header', 'Guarulhos, ' . date('F jS Y')); ?>

<?php $__env->startSection('conteudo'); ?>

    <div class="row">
        <div class="col-md-6 container-fluid">

            <div class="card card-purple">
                <div class="card-header">
                    <h3 class="card-title">Escolaridades</h3>
                    <div class="card-tools">
                        <a class="btn-xs bg-indigo" href="<?php echo e(route('escolaridade.create')); ?>">Cadastrar Nova Escolaridade</a>
                    </div>
                </div>

                <div class="card-body">
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th style="width: 10px">ID</th>
                                <th>Escolaridade</th>
                                <th style="width: 40px">Ação</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $escolaridades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $escolaridade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($escolaridade->id); ?></td>
                                    <td><?php echo e($escolaridade->descricao); ?></td>
                                    <td><a href="<?php echo e(route('escolaridade.edit', $escolaridade->id)); ?>" class="btn-xs bg-success">Editar</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fviriato/Documents/Code/ocean-languages/resources/views/app/_config/escolaridade/index.blade.php ENDPATH**/ ?>