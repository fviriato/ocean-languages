<?php $__env->startSection('titulo', 'Professor'); ?>

<?php $__env->startSection('content_header', 'Guarulhos, ' . date('F jS Y')); ?>

<?php $__env->startSection('conteudo'); ?>

    <div class="row">
        <div class="col-md-9 container-fluid">

            <div class="card">
                <div class="card-header bg-gradient-olive">
                    <h3 class="card-title">MENU DE PROFESSORES</h3>
                </div>
                <div class="card-body">
                    <a class="btn btn-app" href="<?php echo e(route('professor.create')); ?>">
                        <i class="fas fa-file-signature"></i>Cadastrar
                    </a>
                    <a class="btn btn-app" href="<?php echo e(route('idioma.index')); ?>">
                        <i class="fas fa-chalkboard"></i>Matérias
                    </a>
                    <a class="btn btn-app" href="<?php echo e(route('professor.index')); ?>">
                        <i class="fas fa-restroom"></i>Professores
                    </a>
                    <a class="btn btn-app">
                        <i class="fas fa-file-word"></i>Relatórios
                    </a>

                </div>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fviriato/Documents/Code/ocean-languages/resources/views/app/professor/home.blade.php ENDPATH**/ ?>