<?php $__env->startSection('titulo', "<?php echo e(date('y/d/Y')); ?>"); ?>

<?php $__env->startSection('content_header', 'Guarulhos, ' . date('F jS Y')); ?>

<?php $__env->startSection('conteudo'); ?>

    <div class="row">
        <div class="col-md-10 container-fluid">
            <div class="card card-purple">
                <div class="card-header">
                    <h3 class="card-title">Módulo Pedagógico</h3>
                </div>
                <div class="card-body">
                    <a class="btn btn-app" href="<?php echo e(route('nivel.index')); ?>">
                        <i class="fas fa-layer-group"></i>Nível de Ensino
                    </a>
                    <a class="btn btn-app" href="<?php echo e(route('estagio.index')); ?>">
                        <i class="fas fa-signal"></i>Estágio de Ensino
                    </a>
                    <a class="btn btn-app" href="<?php echo e(route('idiomaDisciplina.index')); ?>">
                        <i class="fas fa-language"></i>Idioma / Disciplina
                    </a>
                    <a class="btn btn-app" href="<?php echo e(route('curso.index')); ?>">
                        <i class="fas fa-book-open"></i></i>Cursos
                    </a>
                    <a class="btn btn-app" href="<?php echo e(route('turma.index')); ?>">
                        <i class="fas fa-users-viewfinder"></i>Turmas de Alunos
                    </a>


                    <a class="btn btn-app" href="">
                        <i class="fas fa-school"></i> Escolas
                    </a>
                    <a class="btn btn-app" href="">
                        <i class="fas fa-graduation-cap"></i>Escolaridades
                    </a>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fviriato/Documents/Code/ocean-languages/resources/views/app/pedagogico.blade.php ENDPATH**/ ?>