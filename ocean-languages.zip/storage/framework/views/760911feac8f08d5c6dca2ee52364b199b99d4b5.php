<?php $__env->startSection('titulo', 'Estágio de Ensino'); ?>

<?php $__env->startSection('content_header', 'Guarulhos, ' . date('F jS Y')); ?>

<?php $__env->startSection('conteudo'); ?>

    <div class="row">
        <div class="col-md-6 container-fluid">

            <div class="card card-purple">
                <div class="card-header">
                    <h3 class="card-title">
                        <?php echo e(isset($estagio->id) ? 'Editar Estágio de Ensino do Idioma' : 'Cadastrar Estágio de Ensino do Idioma'); ?>

                    </h3>
                    <div class="card-tools">
                        <a class="btn-xs bg-indigo" href="<?php echo e(route('estagio.index')); ?>">Voltar</a>
                    </div>
                </div>

                <?php if($errors->any()): ?>
                    <div class="row" style="padding-top: 10px;padding-bottom: -30px">
                        <div class="col-sm-11 container-fluid">
                            <ul class="alert alert-default-danger alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="error"><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if(!empty($estagio->id)): ?>
                    <form method="POST" action="<?php echo e(route('estagio.update', ['estagio' => $estagio->id])); ?>">
                        <?php echo method_field('PUT'); ?>
                    <?php else: ?>
                        <form method="POST" action="<?php echo e(route('estagio.store')); ?>">
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="card-body">

                    <div class="row">

                        <div class="form-group col-sm-8">
                            <label for="exampleInputEmail1">Nome</label>
                            <input type="text" class="form-control form-control-sm" name="nome"
                                id="exampleInputEmail1" placeholder="Estágio de Ensino"
                                value="<?php echo e($estagio->nome ?? old('nome')); ?>">
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-sm-12">
                            <label for="descricao">Descrição do Estágio </label>
                            <textarea class="form-control" placeholder="Descrição do Estágio de ensino" name="descricao" id="descricao"
                                rows="3"><?php echo e($estagio->descricao ?? null); ?></textarea>
                        </div>
                    </div>
                </div>

                <div class="card-footer">
                    <button type="submit"
                        class="btn btn-primary"><?php echo e(isset($estagio->id) ? 'Atualizar' : 'Cadastrar'); ?></button>
                </div>
                </form>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fviriato/Documents/Code/ocean-languages/resources/views/app/_config/estagio/create.blade.php ENDPATH**/ ?>