<?php $__env->startSection('titulo', "<?php echo e(date('y/d/Y')); ?>"); ?>

<?php $__env->startSection('content_header', 'Guarulhos, ' . date('F jS Y')); ?>

<?php $__env->startSection('conteudo'); ?>



    <div class="row">
        <div class="col-md-8 container-fluid">
            <h5 class="text-center text-success"><?php echo e(Auth::user()->name); ?>, Seja Bem Vindo(a)!</h5>
            <br>
            <br>
            <h1 class="text-center text-purple">Ocean Languages</h1>
            <br>
            <br>
            <h2 class="text-center text-primary">Sistema de Gestão</h2>
            <br>
            
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fviriato/Documents/Code/ocean-languages/resources/views/app/home.blade.php ENDPATH**/ ?>