<?php $__env->startSection('titulo', "<?php echo e(date('y/d/Y')); ?>"); ?>

<?php $__env->startSection('content_header', 'Guarulhos, ' . date('F jS Y')); ?>

<?php $__env->startSection('conteudo'); ?>

    <div class="row">
        <div class="col-md-10 container-fluid">
            <div class="card card-purple">
                <div class="card-header">
                    <h3 class="card-title">Módulo Administrativo</h3>
                </div>
                <div class="card-body">
                    <a class="btn btn-app" href="<?php echo e(route('aluno.home')); ?>">
                        <i class="fas fa-users"></i>Alunos
                    </a>
                    <a class="btn btn-app" href="<?php echo e(route('professor.home')); ?>">
                        <i class="fas fa-graduation-cap"></i> Professores
                    </a>
                    <a class="btn btn-app" href="<?php echo e(route('matricular.index')); ?>">
                        <i class="fas fa-layer-group"></i>Matriculas
                    </a>
                    <a class="btn btn-app" href="<?php echo e(route('colaborador.index')); ?>">
                        <i class="fas fa-restroom"></i>Funcionários
                    </a>
                    
                    

                    <hr>

                    <h6 class="text-purple">Configurações do Sistema</h6>

                    <br>
                    <a class="btn btn-app" href="<?php echo e(route('genero.index')); ?>">
                        <i class="fas fa-venus-mars"></i>Gênero
                    </a>
                    <a class="btn btn-app" href="<?php echo e(route('escola.index')); ?>">
                        <i class="fas fa-school"></i> Escolas
                    </a>
                    <a class="btn btn-app" href="<?php echo e(route('escolaridade.index')); ?>">
                        <i class="fas fa-graduation-cap"></i>Escolaridades
                    </a>
                    <a class="btn btn-app" href="<?php echo e(route('nivel.index')); ?>">
                        <i class="fas fa-layer-group"></i>Nível de Ensino
                    </a>
                    <a class="btn btn-app" href="<?php echo e(route('estagio.index')); ?>">
                        <i class="fas fa-signal"></i>Estágio de Ensino
                    </a>
                    <a class="btn btn-app" href="<?php echo e(route('idiomaDisciplina.index')); ?>">
                        <i class="fas fa-language"></i>Idioma / Disciplina
                    </a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fviriato/Documents/Code/ocean-languages/resources/views/app/administrativo.blade.php ENDPATH**/ ?>