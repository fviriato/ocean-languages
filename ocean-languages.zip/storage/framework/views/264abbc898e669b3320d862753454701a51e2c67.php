<?php $__env->startSection('titulo', 'Matricular Aluno'); ?>

<?php $__env->startSection('content_header', 'Guarulhos, ' . date('F jS Y')); ?>

<?php $__env->startSection('conteudo'); ?>

    <div class="row">
        <div class="col-md-10 container-fluid">
            <div class="card card-purple">
                <div class="card-header">
                    <h3 class="card-title">Matricular Aluno</h3>
                    <div class="card-tools">
                        <a class="btn-xs bg-indigo" href="<?php echo e(route('aluno.home')); ?>">Voltar</a>
                    </div>
                </div>

                <?php if($errors->any()): ?>
                    <div class="row" style="padding-top: 10px;padding-bottom: -30px">
                        <div class="col-sm-11 container-fluid">
                            <ul class="alert alert-default-danger alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="error"><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if(!empty($aluno->id)): ?>
                    <form method="POST" action="<?php echo e(route('aluno.update', ['aluno' => $aluno->id])); ?>">
                        <?php echo method_field('PUT'); ?>
                    <?php else: ?>
                        <form method="POST" action="<?php echo e(route('aluno.store')); ?>">
                <?php endif; ?>

                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="row">
                        <div class="form-group col-sm-6">
                            <label for="genero_id">Aluno</label>
                            <select name="genero_id" class="form-control form-control-sm" id="genero_id">
                                <option></option>
                                <?php $__currentLoopData = $generos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($genero->id); ?>"
                                        <?php echo e($aluno->genero_id ?? old('genero_id') == $genero->id ? 'selected' : ''); ?>>
                                        <?php echo e($genero->nome); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>

                        <div class="form-group col-sm-4">
                            <label for="genero_id">Curso</label>
                            <select name="genero_id" class="form-control form-control-sm" id="genero_id">
                                <option></option>
                                <?php $__currentLoopData = $generos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($genero->id); ?>"
                                        <?php echo e($aluno->genero_id ?? old('genero_id') == $genero->id ? 'selected' : ''); ?>>
                                        <?php echo e($genero->nome); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>


                    <div class="row">

                        <div class="form-group col-sm-5">
                            <label for="genero_id">Turma</label>
                            <select name="genero_id" class="form-control form-control-sm" id="genero_id">
                                <option></option>
                                <?php $__currentLoopData = $generos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($genero->id); ?>"
                                        <?php echo e($aluno->genero_id ?? old('genero_id') == $genero->id ? 'selected' : ''); ?>>
                                        <?php echo e($genero->nome); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>


                        <div class="form-group col-sm-2">
                            <label for="estado">Valor Mensal</label>
                            <input type="text" name="valor_mensal" class="form-control form-control-sm" id="estado"
                                value="<?php echo e($aluno->endereco->estado ?? old('estado')); ?>" placeholder="Ex. São Paulo">
                        </div>
                        <div class="form-group col-sm-2">
                            <label for="estado">Data Pagamento</label>
                            <input type="number" name="data_pagamento" class="form-control form-control-sm" id="estado"
                                value="<?php echo e($aluno->endereco->estado ?? old('estado')); ?>" min="1" max="31" step="1" placeholder="Ex. 10">
                        </div>
                    </div>

                </div>


                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fviriato/Documents/Code/ocean-languages/resources/views/app/matricula/enroll.blade.php ENDPATH**/ ?>