<?php $__env->startSection('titulo', 'Nível de Ensino'); ?>

<?php $__env->startSection('content_header', 'Nível de Ensino'); ?>

<?php $__env->startSection('conteudo'); ?>

    <div class="row">
        <div class="col-md-10 container-fluid">

            <div class="card card-purple">
                <div class="card-header">
                    <h3 class="card-title">Nível de Ensino</h3>
                    <div class="card-tools">
                        <a class="btn-xs bg-indigo" href="<?php echo e(route('nivel.create')); ?>">Cadastrar Nível de Ensino</a>
                    </div>
                </div>

                <div class="card-body">
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Nível</th>
                                <th>Sigla</th>
                                <th>Descrição</th>
                                <th style="width: 40px">Ação</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $niveis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nivel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($nivel->nome); ?></td>
                                    <td><?php echo e($nivel->sigla); ?></td>
                                    <td><?php echo e($nivel->descricao); ?></td>
                                    <td><a href="<?php echo e(route('nivel.edit', $nivel->id)); ?>" class="btn-xs bg-success">Editar</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fviriato/Documents/Code/ocean-languages/resources/views/app/_config/nivel/index.blade.php ENDPATH**/ ?>